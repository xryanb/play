from flask import Flask, render_template

app = Flask(__name__)

from flask import Flask, render_template
app = Flask(__name__)
@app.route('/play')
def index():
    return render_template("index.html", phrase="Welcome", times=5)	# notice the 2 new named arguments!

@app.route('/play/<int:num>')
def index2(num):
    return render_template("index2.html", phrase="Welcome", num=num)

@app.route('/play/<int:numb>/<string:color>')
def index3(numb,color):
    return render_template("index3.html", phrase="Welcome", numb=numb,color=color)

if __name__=="__main__":
    app.run(debug=True)

